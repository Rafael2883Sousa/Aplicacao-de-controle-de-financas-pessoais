package com.example.projetoprtico_controledefinanas;

import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView totalExpenses;
    private TextView totalIncome;
    private TextView currentBalance;
    private Button btnViewTransactions;
    private Button btnAddIncome;
    private Button btnAddExpense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        currentBalance = findViewById(R.id.current_balance);
        totalIncome = findViewById(R.id.total_income);
        totalExpenses = findViewById(R.id.total_expenses);
        btnAddIncome = findViewById(R.id.btn_add_income);
        btnAddExpense = findViewById(R.id.btn_add_expense);
        btnViewTransactions = findViewById(R.id.btn_view_transactions);

        btnAddIncome.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TransactionFormActivity.class);
            intent.putExtra("type", "income");
            startActivity(intent);
        });

        btnAddExpense.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TransactionFormActivity.class);
            intent.putExtra("type", "expense");
            startActivity(intent);
        });

        btnViewTransactions.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TransactionListActivity.class);
            startActivity(intent);
        });
    }
}