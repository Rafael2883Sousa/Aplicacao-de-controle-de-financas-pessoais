package com.example.projetoprtico_controledefinanas;

import android.os.Bundle;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class TransactionListActivity extends AppCompatActivity {

    private RecyclerView transactionRecyclerView;
    private TransactionViewModel transactionViewModel;
    private TransactionAdapter transactionAdapter;
    private List<Transaction> transactionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_transaction_list);

        transactionRecyclerView = findViewById(R.id.recycler_view_transactions);
        transactionRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        transactionViewModel = new ViewModelProvider(this).get(TransactionViewModel.class);

        transactionViewModel.getAllTransactions().observe(this, transactions -> {
            transactionAdapter = new TransactionAdapter(transactions, this::onTransactionLongClick);
            transactionRecyclerView.setAdapter(transactionAdapter);
        });

    }

    private void onTransactionLongClick(Transaction transaction) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Transaction Options")
                .setItems(new String[]{"Edit", "Delete"}, (dialog, which) -> {
                    if (which == 0) {
                        editTransaction(transaction);
                    } else if (which == 1) {
                        deleteTransaction(transaction);
                    }
                })
                .show();
    }

    private void editTransaction(Transaction transaction) {
        Toast.makeText(this, "Edit functionality not yet implemented", Toast.LENGTH_SHORT).show();
    }

    private void deleteTransaction(Transaction transaction) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Deletion")
                .setMessage("Are you sure you want to delete this transaction?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    transactionViewModel.delete(transaction);
                    Toast.makeText(this, "Transaction deleted", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("No", null)
                .show();
    }
}